Number.prototype.won = function() {
	str = String(this.valueOf());
    return "&#8361;"+str.replace(/(\d)(?=(?:\d{3})+(?!\d))/g, '$1,');
}

Number.prototype.comma = function() {
    str = String(this.valueOf());
    return str.replace(/(\d)(?=(?:\d{3})+(?!\d))/g, '$1,');
}

Number.prototype.hwon = function() {
	var num = String(this.valueOf());
	var hanA = new Array("","일","이","삼","사","오","육","칠","팔","구","십");  
    var danA = new Array("","십","백","천","","십","백","천","","십","백","천");  
    var result = "";

    if(!isNaN(num)) {
        for(i=0; i<num.length; i++) {  
            str = "";  
            han = hanA[num.charAt(num.length-(i+1))];  
            if(han != "") str = han+danA[i];  
            if(i == 4) str += "만";  
            if(i == 8) str += "억";  
            result = str + " " + result;  
        }
    }

    return result + "원";  
}
/* Print Project */
$.fn.pp = function(project) {
	var item_template = '<tr> \
            <td>인쇄</td> \
            <td class="tc">[[[PRODUCT-DESCRIPTION]]]</td> \
            <td class="tr">[[[QUANTITY]]]</td> \
            <td class="tr">[[[UNIT-PRICE]]]</td> \
            <td class="tr">[[[VAT]]]</td> \
            <td class="tr">[[[REMARK]]]</td> \
        </tr>';
	var template = '<table class="mq-table pure-table-bordered pure-table tb-tick-border"> \
        <thead> \
            <tr> \
                <th class="tc content-title" colspan="6"><span class="project-name">[[[PROJECT-NAME]]]</span></th> \
            </tr> \
            <tr> \
                <th class="tc">내용</th> \
                <th class="tc" style="width:40px">수량</th> \
                <th class="tc" style="width:100px">단가</th> \
                <th class="tc" style="width:150px">공급가액</th> \
                <th class="tc" style="width:150px">세액</th> \
                <th class="tc" style="width:150px">비고</th> \
            </tr> \
        </thead> \
        <tbody> \
[[[PROJECTS]]] \
            <tr class="sum"> \
                <td class="tc" colspan="3">소계</td> \
                <td class="tr">[[[PROJECT-COST]]]</td> \
                <td class="tr">[[[PROJECT-VAT]]]</td> \
                <td></td> \
            </tr> \
        </tbody> \
    </table>';

    // [[[project-name]]]
    template = template.replace("[[[PROJECT-NAME]]]", project.name);
    template = template.replace("[[[PROJECT-COST]]]", project.sum.cost.won());
    template = template.replace("[[[PROJECT-VAT]]]", project.sum.vat.won());

    var item_htmls = "";
	$.each(project.items, function(index2, item) {
		var item_html = "";
    	item_html = item_template.replace("[[[PRODUCT-DESCRIPTION]]]", item.product_description);
    	item_html = item_html.replace("[[[QUANTITY]]]", item.quantity.won());
    	item_html = item_html.replace("[[[UNIT-PRICE]]]", item.unit_price.won());
    	item_html = item_html.replace("[[[VAT]]]", item.vat.won());
    	item_html = item_html.replace("[[[REMARK]]]", item.remark);
    	item_htmls += item_html;
    });

    template = template.replace("[[[PROJECTS]]]", item_htmls);

    return $(this).prepend(template);
};